# Makeup-website

![Capture](https://user-images.githubusercontent.com/67097151/129464659-2bc7dd92-82b2-4949-b221-1ffe411c5915.JPG)

1. Introduction:

This is a makeup website where you can see various products related to eyes, hairs, lips and face. You can place orders for them by using the add to cart functionality. This website allows you to add comments, sign up and all the basal services that a website provides.

2. Scope:

This is a user-friendly site that can help to attract more customers by using the images of products and providing them with an easy way of ordering things. By this, they can keep a record of them. Moreover, it will be faultless and efficient in case of totalling bills. This is the best way of keeping customers updated about the new arrivals.

3.Module Description:

This project consists of various pages and subpages that are:

- Categories
  1. Lips
  2. Eyes
  3. Hairs
  4. Face
- Sign Up
- Contact Us
- Privacy Policy

![Capture 1](https://user-images.githubusercontent.com/67097151/129464661-3ddd6ae9-bc3c-4e5a-9a29-8f8dfd4ca54f.JPG)


![Capture2](https://user-images.githubusercontent.com/67097151/129464660-5c3393cb-8776-4de2-be76-10abf33b40dd.JPG)


The Categories page provide the cart functionality. It uses JavaScript event listeners, query selectors and local storage to provide cart service. Each product type eyes, lips, hairs and face contain various products with the add to cart button. By clicking this button, the record is added to your cart that you can see on the cart page. Next, we have a signup page that offers you a form for signing up. Then we have a contact us page that allows the user to get the details and add a message. Lastly, we have a privacy policy page that includes the documentation for the privacy of the website.

4.Hardware/Software Requirements:
- Sublime Text


Go to this link to access the project: https://mehwishsameer.github.io/Makeup-website/
